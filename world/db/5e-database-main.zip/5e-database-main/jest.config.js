module.exports = {
  testRegex: "test\\.js$",
  coveragePathIgnorePatterns: ["/node_modules/"],
};
